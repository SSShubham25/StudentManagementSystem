package com.shubham.studentmanagement.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.shubham.studentmanagement.dto.Student;

@Component
public class StudentDAO {
	
	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	private EntityTransaction entityTransaction;
	
	private void openConnection() {
		entityManagerFactory = Persistence.createEntityManagerFactory("springmvc");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
	}
	
	private void closeConnection() {
		if (entityManagerFactory != null)
			entityManagerFactory.close();
		if (entityManager != null)
			entityManager.close();
		if (entityTransaction != null) {
			if (entityTransaction.isActive())
				entityTransaction.rollback();
		}
	}


	public void addStudent(Student student) {
		openConnection();
		entityTransaction.begin();
		entityManager.persist(student);
		entityTransaction.commit();
		closeConnection();

		
	}

	@SuppressWarnings("unchecked")
	public List<Student> findAllStudent() {
		openConnection();
		Query query = entityManager.createQuery("Select students from Student students");
		List<Student> students= query.getResultList();
		closeConnection();
		
		return students;
		
	}
	
	public void deleteStudent(int id) {
		openConnection();
		entityTransaction.begin();
		Student student = entityManager.find(Student.class, id);
		entityManager.remove(student);
		entityTransaction.commit();
		closeConnection();
		
	}

	public Student findStudentById(int id) {
		openConnection();
		Student student= entityManager.find(Student.class, id);
		closeConnection();
		return student;
		
	}

	public void updateStudet(int id, String name, String email, long mobile, String course) {
		openConnection();
		entityTransaction.begin();
		Student student= entityManager.find(Student.class, id);
		student.setName(name);
		student.setEmail(email);
		student.setMobile(mobile);
		student.setCourse(course);
		entityManager.persist(student);
		entityTransaction.commit();
		closeConnection();
		
	}

	public Student findStudentByMobile(long mobile) {
		openConnection();
		Query query =entityManager.createQuery("SELECT student FROM Student student WHERE student.mobile = ?1");
		query.setParameter(1, mobile);
		Student student= (Student) query.getSingleResult();
		closeConnection();
		return student;
		
	}

	@SuppressWarnings("unchecked")
	public List<Student> findStudentByName(String name) {
		openConnection();
		Query query = entityManager.createQuery("SELECT students FROM Student students WHERE students.name = ?1");
		query.setParameter(1, name);
		List<Student> students =  query.getResultList();
		closeConnection();
		return students;
		
	}

	public Student findStudentByEmail(String email) {
		openConnection();
		Query query =entityManager.createQuery("SELECT student FROM Student student WHERE student.email = ?1");
		query.setParameter(1, email);
		Student student= (Student) query.getSingleResult();
		closeConnection();
		return student;
	}

	@SuppressWarnings("unchecked")
	public List<Student> findStudentByCourse(String course) {
		openConnection();
		Query query = entityManager.createQuery("SELECT students FROM Student students WHERE students.course = ?1");
		query.setParameter(1, course);
		List<Student> students =  query.getResultList();
		closeConnection();
		return students;
	}

}
