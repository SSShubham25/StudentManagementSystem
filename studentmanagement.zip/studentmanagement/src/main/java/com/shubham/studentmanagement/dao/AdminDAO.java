package com.shubham.studentmanagement.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.shubham.studentmanagement.dto.Admin;

@Component
public class AdminDAO {
	
	private EntityManager entityManager;
	private EntityManagerFactory entityManagerFactory;
	private EntityTransaction entityTransaction;
	
	private void openConnection() {
		entityManagerFactory = Persistence.createEntityManagerFactory("springmvc");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		
	}
	
	private void closeConnection() {
		if(entityManagerFactory != null)
			entityManagerFactory.close();
		if(entityManager != null)
			entityManager.close();
		if(entityTransaction != null)
			if(entityTransaction.isActive())
				entityTransaction.rollback();
	}



	public void addAdmin(Admin admin) {
		openConnection();
		entityTransaction.begin();
		entityManager.persist(admin);
		entityTransaction.commit();
		closeConnection();
		
	}

	public Admin authenticateAdmin(String email, String password) {
		openConnection();
		Query query = entityManager.createQuery("select admin from Admin admin where admin.email=?1 and admin.password = ?2");
		query.setParameter(1, email);
		query.setParameter(2, password);
		Admin admin= (Admin) query.getSingleResult();
		closeConnection();
		return admin;
		
	}
	
	
	

}
