package com.shubham.studentmanagement.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.shubham.studentmanagement.dto.Admin;
import com.shubham.studentmanagement.dto.Student;
import com.shubham.studentmanagement.service.StudentService;

@Controller
public class StudentController {
	@Autowired
	StudentService studentService;

	@RequestMapping(path = "/add-student-page")
	protected String signUp(HttpSession httpSession) {
		Admin admin =  (Admin) httpSession.getAttribute("authenticated_admin");
		if(admin != null) {
			return "add_student";
		}else
			return "login";
	}

	@RequestMapping(path = "/index")
	protected String home(ModelMap modelMap, HttpSession httpSession ) {
		Admin admin =  (Admin) httpSession.getAttribute("authenticated_admin");
		if(admin != null) {
			return "index";	
		}else
			return "login";
	}

	@RequestMapping(path = "/all-students")
	protected String students(ModelMap modelMap, HttpSession httpSession) {
		List<Student> students = studentService.findAllStudent();
		modelMap.addAttribute("student", students);
		Admin admin =  (Admin) httpSession.getAttribute("authenticated_admin");
		if(admin != null) {
			return "students";
		}else
			return "login";
	}

	@RequestMapping(path = "/add-student", method = RequestMethod.POST)
	protected String addStudent(@RequestParam(name = "name") String name, @RequestParam(name = "email") String email,
			@RequestParam(name = "mobile") long mobile, @RequestParam(name = "course") String course, ModelMap map, HttpSession httpSession) {

		boolean studentAdded = studentService.addStudent(name, email, mobile, course);
		List<Student> students = studentService.findAllStudent();
		if (studentAdded) {
			map.addAttribute("student", students);
			map.addAttribute("message", "Student Added");

		} else {
			if (students != null)
				map.addAttribute("student", students);

			map.addAttribute("message", "Something Went Wrong");
		}
		Admin admin =  (Admin) httpSession.getAttribute("authenticated_admin");
		if(admin != null) {
			return "students";
		}else {
			return "login";
		}
	}

	@RequestMapping(path = "/students")
	protected String findAllStudent(ModelMap modelMap, HttpSession httpSession) {
		List<Student> students = studentService.findAllStudent();
		if (students != null) {
			modelMap.addAttribute("students", students);

		} else {
			modelMap.addAttribute("message", "No Data Avilable");
		}
		Admin admin =  (Admin) httpSession.getAttribute("authenticated_admin");
		if(admin != null) {
			return "students";
		}else {
			return "login";
		}
	}

	@RequestMapping(path = "/delete-student")
	protected String deleteStudent(@RequestParam(name = "id") int id, ModelMap modelMap, HttpSession httpSession) {
		boolean studentDeleted = studentService.deleteStudent(id);
		List<Student> students = studentService.findAllStudent();
		if (studentDeleted) {
			modelMap.addAttribute("message", "Student Deleted");
			if (students != null)
				modelMap.addAttribute("student", students);
			else {
				modelMap.addAttribute("message", "No Data Found");
			}
		} else {
			modelMap.addAttribute("message", "Something went wrong");
			if (students != null)
				modelMap.addAttribute("student", students);
			else {
				modelMap.addAttribute("message", "Data Not Found");
			}
		}
		Admin admin =  (Admin) httpSession.getAttribute("authenticated_admin");
		if(admin != null) {
			return "students";
		}else {
			return "login";
		}
	}

	@RequestMapping(path = "/edit-student")
	protected String editStudent(@RequestParam(name = "id") int id, ModelMap modelMap, HttpSession httpSession) {
		Student student = studentService.findStudentById(id);
		modelMap.addAttribute("student", student);
		Admin admin =  (Admin) httpSession.getAttribute("authenticated_admin");
		if(admin != null) {
			return "edit_student";
		}else {
			return "login";
		}
//		return "edit_student";
	}

	@RequestMapping(path = "/update-student", method = RequestMethod.POST)
	protected String addStudent(@RequestParam(name = "id") int id, @RequestParam(name = "name") String name,
			@RequestParam(name = "email") String email, @RequestParam(name = "mobile") long mobile,
			@RequestParam(name = "course") String course, ModelMap map, HttpSession httpSession) {

		boolean updatedStudent = studentService.updateStudent(id, name, email, mobile, course);
		List<Student> students = studentService.findAllStudent();
		if (updatedStudent) {
			map.addAttribute("message", "Student Updated");

		} else {
			map.addAttribute("message", "Something Went Wrong");

		}
		map.addAttribute("student", students);
//		return "students";
		Admin admin =  (Admin) httpSession.getAttribute("authenticated_admin");
		if(admin != null) {
			return "students";
		}else {
			return "login";
		}
	}

	@RequestMapping(path = "find-student")
	protected String findStudent() {
		return "find";

	}

	@RequestMapping(path = "/mobile" , method = RequestMethod.POST)
	protected String findStudentByMobile(@RequestParam(name = "mobile") long mobile, ModelMap modelMap) {
		Student student = studentService.findStudentByMobile(mobile);
		if (student != null)
			modelMap.addAttribute("student", student);
		else {
			modelMap.addAttribute("message", "Student Not Found");
		}
		return "mobile";

	}
	
	@RequestMapping(path = "/name")
	protected String findStudentByName( @RequestParam(name = "name") String name, ModelMap modelMap) {
		List<Student> students = studentService.findStudentByName(name);
		if(students != null) {
			modelMap.addAttribute("students", students);
		}else{
			modelMap.addAttribute("message", "Student Not Found");
		}
		return "name";
			
	}
	
	@RequestMapping(path = "/email" , method = RequestMethod.POST)
	protected String findStudentByEmail(@RequestParam(name = "email") String email , ModelMap modelMap) {
		Student student = studentService.findStudentByEmail(email);
		if (student != null)
			modelMap.addAttribute("student", student);
		else {
			modelMap.addAttribute("message", "Student Not Found");
		}
		return "email";
	}
	
	@RequestMapping(path = "/course" )
	protected String findStudentByCourse( @RequestParam(name = "course") String course, ModelMap modelMap) {
		List<Student> students = studentService.findStudentByCourse(course);
		if(students != null) {
			modelMap.addAttribute("students", students);
		}else{
			modelMap.addAttribute("message", "Student Not Found");
		}
		return "course";		
	}

}
