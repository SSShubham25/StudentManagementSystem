package com.shubham.studentmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.shubham.studentmanagement.dao.AdminDAO;
import com.shubham.studentmanagement.dto.Admin;

@Component
public class AdminService {

	@Autowired
	AdminDAO adminDAO;
	Admin admin = new Admin();
	
	public boolean addAdmin(String email, String password) {
		admin.setEmail(email);
		admin.setPassword(password);
		try {
			adminDAO.addAdmin(admin);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	public Admin authenticateAdmin(String email, String password) {
		try {
			Admin authenticatedAdmin = adminDAO.authenticateAdmin(email, password);
			if(authenticatedAdmin.getEmail().equals(email) && authenticatedAdmin.getPassword().equals(password))
				return authenticatedAdmin;
			else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		
	}

}
