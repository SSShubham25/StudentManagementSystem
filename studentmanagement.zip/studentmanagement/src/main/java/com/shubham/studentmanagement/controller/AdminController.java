package com.shubham.studentmanagement.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.shubham.studentmanagement.dto.Admin;
import com.shubham.studentmanagement.service.AdminService;

@Controller
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	@RequestMapping(path = "/sign-up")
	protected String signUp() {
		return "signup";	
	}
	
	@RequestMapping(path = "/login")
	protected String login() {
		return "login";	
	}
	
	@RequestMapping(path = "/add-admin", method = RequestMethod.POST)
	protected String addAdmin1(@RequestParam(name = "email") String email, @RequestParam(name = "password") String password , ModelMap modelMap) {
		boolean adminAdded = adminService.addAdmin(email,password);
		if(adminAdded) {
			modelMap.addAttribute("message", "Admin Added Successfully");
			return "login";
		}else {
			modelMap.addAttribute("message", "Something Went Wrong");
			return "signup";
		}	
	}
	
	@RequestMapping(path = "/auth-admin" , method = RequestMethod.POST)
	protected String authenticateAdmin(@RequestParam(name = "email") String email, @RequestParam(name = "password") String password , ModelMap modelMap , HttpSession httpSession) {
		Admin authenticatedAdmin = adminService.authenticateAdmin(email, password);
		if(authenticatedAdmin != null) {
			httpSession.setAttribute("authenticated_admin", authenticatedAdmin);
			return "index";
		}else
			
			return "login";
		
	}
	
	


}
